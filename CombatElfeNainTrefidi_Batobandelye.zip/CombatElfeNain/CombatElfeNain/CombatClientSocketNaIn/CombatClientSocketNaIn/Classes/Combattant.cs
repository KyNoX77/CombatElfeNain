﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CombatClientSocketNaIn.Classes
{
    public class Combattant
    {
        public int Force { get; set; }
        public int Vie { get; set; }
        public Image Avatar {get; set;}
    }
}
