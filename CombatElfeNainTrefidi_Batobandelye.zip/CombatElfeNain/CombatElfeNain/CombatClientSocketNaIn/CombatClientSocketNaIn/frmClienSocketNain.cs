﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CombatClientSocketNaIn.Classes;


namespace CombatClientSocketNaIn
{
    public partial class frmClienSocketNain : Form
    {
        Random m_r;
        Elfe m_elfe;
        Nain m_nain;

        public frmClienSocketNain()
        {
            InitializeComponent();
            m_r = new Random();
            Reset();
            btnReset.Enabled = false;
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        void Reset()
        {
            m_nain = new Nain(m_r.Next(10, 20), m_r.Next(2, 6), m_r.Next(0, 3));
            picNain.Image = m_nain.Avatar;
            lblVieNain.Text = "Vie: " + m_nain.Vie.ToString(); ;
            lblForceNain.Text = "Force: " + m_nain.Force.ToString();
            lblArmeNain.Text = "Arme: " + m_nain.Arme;

            m_elfe = new Elfe(1, 0, 0);
            picElfe.Image = m_elfe.Avatar;
            lblVieElfe.Text = "Vie: " + m_elfe.Vie.ToString();
            lblForceElfe.Text = "Force: " + m_elfe.Force.ToString();
            lblSortElfe.Text = "Sort: " + m_elfe.Sort.ToString();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            btnFrappe.Enabled = true;
            Reset();
        }

        private void btnFrappe_Click(object sender, EventArgs e)
        {
            //déclaration des variables
            Socket Client;
            string envoie = "";
            string EnvoiSats;
            int nbOctetReception;
            byte[] tByteReceptionClient = new byte[100];
            ASCIIEncoding textByte = new ASCIIEncoding();
            byte[] tByteEnvoie = textByte.GetBytes(envoie);
            string reponse;
            string[] tRecup;
            btnFrappe.Enabled = false;
            btnReset.Enabled = false;


            try
            {
                //création d'un objet socket et connection
                Client = new Socket(SocketType.Stream, ProtocolType.Tcp);
                Client.Connect(IPAddress.Parse("127.0.0.1"), 9999);
                MessageBox.Show("assurez-vous que le serveur est démarré et en attente d'un client");

                if (Client.Connected)
                {
                    EnvoiSats = m_nain.Vie + ";" + m_nain.Force + ";" + m_nain.Arme;
                    MessageBox.Show("Client: \r\nTransmet..." + EnvoiSats);
                    tByteEnvoie = textByte.GetBytes(EnvoiSats);

                    Client.Send(tByteEnvoie);
                    Thread.Sleep(500);

                    MessageBox.Show("Client: réception de données serveur");

                    nbOctetReception = Client.Receive(tByteReceptionClient);

                    reponse = Encoding.ASCII.GetString(tByteReceptionClient);
                    MessageBox.Show("\r\nReception..." + reponse);

                    //split sur le tring de réception pour afficher les nouvelles stats du nain et de l'elfe
                    tRecup = reponse.Split(';');


                    lblVieNain.Text = "Vie : " + tRecup[0];
                    lblForceNain.Text = "Force : " + tRecup[1];
                    lblArmeNain.Text = "Arme : " + tRecup[2];

                    m_nain.Vie = Convert.ToInt32(tRecup[0]);
                    m_nain.Force = Convert.ToInt32(tRecup[1]);
                    m_nain.Arme = tRecup[2];

                    lblVieElfe.Text = "Vie : " + tRecup[3];
                    lblForceElfe.Text = "Force : " + tRecup[4];
                    lblSortElfe.Text = "Sort : " + tRecup[5];


                    m_elfe.Vie = Convert.ToInt32(tRecup[3]);
                    m_elfe.Force = Convert.ToInt32(tRecup[4]);
                    m_elfe.Sort = Convert.ToInt32(tRecup[5]);

                }

                //Affichage du gagnant
                if (m_nain.Vie == 0)
                {
                    MessageBox.Show("Veuillez applaudir le gagnant de cette bataille.... MONSIEUR L'ELFE!!!!!!!!!!");
                }
                else if (m_elfe.Vie == 0)
                {
                    MessageBox.Show("Veuillez vous prosterner devant le vainqueur de ce combat...... MONSIEUR LE NAIN!!!!!!");
                }
                Client.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            btnFrappe.Enabled = true;
            btnReset.Enabled = true;

        }


    }
}
